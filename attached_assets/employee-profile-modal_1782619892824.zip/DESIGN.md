---
name: Imperial Sovereign
colors:
  surface: '#0f141a'
  surface-dim: '#0f141a'
  surface-bright: '#353941'
  surface-container-lowest: '#0a0e15'
  surface-container-low: '#181c23'
  surface-container: '#1c2027'
  surface-container-high: '#262a31'
  surface-container-highest: '#31353c'
  on-surface: '#dfe2ec'
  on-surface-variant: '#d6c4af'
  inverse-surface: '#dfe2ec'
  inverse-on-surface: '#2d3138'
  outline: '#9e8e7b'
  outline-variant: '#514535'
  surface-tint: '#ffb954'
  primary: '#ffb954'
  on-primary: '#452b00'
  primary-container: '#c5830c'
  on-primary-container: '#3c2500'
  inverse-primary: '#835500'
  secondary: '#fdbb44'
  on-secondary: '#432c00'
  secondary-container: '#c08505'
  on-secondary-container: '#3a2600'
  tertiary: '#d3c5a8'
  on-tertiary: '#38301b'
  tertiary-container: '#9c9075'
  on-tertiary-container: '#312915'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb4'
  primary-fixed-dim: '#ffb954'
  on-primary-fixed: '#291800'
  on-primary-fixed-variant: '#633f00'
  secondary-fixed: '#ffdead'
  secondary-fixed-dim: '#fdbb44'
  on-secondary-fixed: '#281900'
  on-secondary-fixed-variant: '#604100'
  tertiary-fixed: '#f0e1c3'
  tertiary-fixed-dim: '#d3c5a8'
  on-tertiary-fixed: '#221b08'
  on-tertiary-fixed-variant: '#4f4630'
  background: '#0f141a'
  on-background: '#dfe2ec'
  surface-variant: '#31353c'
  surface-deep: '#20242B'
  surface-card: '#2D3340'
  text-primary: '#F5E6C8'
  text-secondary: '#D2C3A5'
  text-tertiary: '#A89A80'
  accent-gold: '#C4820A'
  accent-glow: rgba(196, 130, 10, 0.14)
  border-subtle: rgba(196, 130, 10, 0.2)
typography:
  display-lg:
    fontFamily: Cinzel
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  headline-md:
    fontFamily: Cinzel
    fontSize: 18px
    fontWeight: '700'
    lineHeight: '1.4'
    letterSpacing: 0.03em
  label-caps:
    fontFamily: Cinzel
    fontSize: 10px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.1em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12.5px
    fontWeight: '400'
    lineHeight: '1.5'
  data-label:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1.2'
  cta:
    fontFamily: Cinzel
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

This design system embodies a persona of **Ornamental Minimalism**—a blend of high-end executive prestige and technical precision. It is designed for enterprise-grade environments where authority, excellence, and meticulous detail are paramount.

The aesthetic draw from **Corporate Modern** structures but elevates them with **Tactile** and **HUD (Heads-Up Display)** influences. It evokes a sense of "The Infinity Castle"—a space that feels both ancient and futuristic, anchored by a deep dark palette and illuminated by "Imperial Gold" accents. The emotional response is one of trust, exclusivity, and focused intelligence. 

Visual hallmarks include:
- **Atmospheric Depth:** Multi-layered backgrounds with geometric "ghost" patterns.
- **Precision Framing:** The use of decorative corner brackets and top-rim gradients to frame content like high-value artifacts.
- **Architectural Hierarchy:** Bold, classical serif headings paired with high-density, utilitarian sans-serif data.

## Colors

The palette is rooted in a **Dark-First** philosophy. The core is a deep charcoal-navy (`#20242B`), providing a low-light foundation that allows gold accents to "glow" with intentionality.

- **Primary Gold (#C4820A):** Used for critical branding, active states, and structural highlights.
- **Secondary Highlight (#E8A832):** Reserved for linear gradients and light-source simulation on the top edges of components.
- **Neutral/Surface:** We utilize a layered approach to surfaces. The base page is the darkest, while containers use a subtle 170-degree linear gradient to create perceived volume.
- **Typography Tiers:** Text colors are not pure white but desaturated creams and golds to reduce eye strain and maintain the "Imperial" theme.

## Typography

This system employs a **dual-font strategy** to balance tradition and utility:
- **Cinzel (Headings/Labels):** Used for all high-level identifiers, role badges, and section headers. Its flared serifs provide the "Imperial" character. Use uppercase for labels to increase the sense of formal structure.
- **Hanken Grotesk (Body/Data):** A sharp, contemporary sans-serif that ensures readability at small sizes. This is crucial for the high-density information grids typical of enterprise dashboards.

**Scale:** We favor smaller, deliberate sizing with generous letter spacing in caps to maintain a sophisticated, "technical document" appearance.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model for primary containers, ensuring the "Castle" structure remains stable and authoritative.

- **The Grid:** A 12-column grid is used for desktop layouts, with content often grouped into "Profile Hubs" or "Data Blocks" spanning 4, 6, or 8 columns.
- **Density:** The system is high-density. We use a 4px base unit. Internal component padding is typically 24px horizontally and 20px vertically to allow data to breathe despite the small font sizes.
- **Responsive Reflow:** 
  - **Desktop:** Multi-column grids with distinct "Sidebars" for metadata.
  - **Tablet:** 2-column flow; 20px gutters.
  - **Mobile:** Single column; margins reduce to 16px. Typography levels above 24px should scale down (e.g., `display-lg` to 24px).

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Subtle Glows** rather than traditional dropshadows.

1.  **Background Texture:** The base layer should feature a low-opacity radial dot pattern or 45-degree rotated squares to provide "material" reality.
2.  **Surface Tiers:**
    - **Tier 1 (Base):** `#20242B`
    - **Tier 2 (Cards):** Linear gradient `#353C48` to `#272C38`.
3.  **Light Sources:** Every card or primary container must have a 2px "Top Rim" gradient (`#C4820A` to `#E8A832`) and a subtle gold inner-shadow at the top to simulate overhead lighting.
4.  **Environmental Shadows:** Use deep, wide-spread shadows (`rgba(0,0,0,0.5)`) for floating containers to separate them from the atmospheric background.

## Shapes

The shape language is **Structured & Contained**. 

- **Primary Containers:** 18px (`rounded-xl`) for main cards to soften the dark, heavy aesthetic.
- **Interactive Elements:** 8px for buttons and 15px for avatars.
- **Data Pills:** Always fully rounded (pill-shaped) to distinguish them from structural UI elements.
- **The "L" Bracket:** Structural containers should feature absolute-positioned 14px "L" brackets in the corners (1.5px width) in primary gold to reinforce the HUD aesthetic.

## Components

### Buttons
- **Primary:** Gold background (`#C4820A`), Cinzel Bold text, 0.06em letter-spacing. Subtle 1px inner-light top border.
- **Hover State:** `translateY(-1px)` with an increased glow effect (`accent-glow`).

### Cards
- Must include the Top Rim gradient.
- Section dividers should be thin `rgba(255,255,255,0.06)` lines to keep the design feeling light.

### Inputs & Fields
- Darkest surface background with a 1px `border-subtle`.
- Focus state: Border color brightens to `#E8A832` with a soft outer gold glow.

### Metadata Pills
- Background: `rgba(255,255,255,0.04)`.
- Border: `rgba(255,255,255,0.08)`.
- Text: `text-tertiary` using Hanken Grotesk.

### Iconography
- Use **Tabler Icons** or similar thin-stroke (1.5px to 2px) icon sets.
- Icons should be muted (`#7A8799`) unless they are interactive or represent a primary brand action, in which case they take the gold accent.